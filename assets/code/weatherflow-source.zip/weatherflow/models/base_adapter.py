"""
Abstract base class that every model adapter must implement.

This contract is the only interface the training loop (training/trainer.py)
ever uses. The trainer has no knowledge of any model's internals beyond these
four methods.

All adapters inherit from BaseAdapter and override these methods. The adapter
pattern preserves the original cloned repository code untouched — it is the
bridge between each model's internal conventions and the shared pipeline.

Optional fifth contract member — per-model loss
-----------------------------------------------
An adapter whose model must train under its own published objective sets the
class attribute `uses_native_loss = True` and defines
`native_loss(pred, target, **kwargs) -> scalar`. The trainer checks that
attribute and, when it is set, calls the adapter's loss instead of the shared
one and skips the classification-subsetting path. `forward` is then free to
return whatever object `native_loss` consumes rather than a plain Tensor.
Adapters that leave it unset (the default, and every production model) take the
shared loss branch. ClimODEFaithfulAdapter is the only shipped opt-in.

Return-shape exceptions
-----------------------
The (batch, H, N, d) return shape below is the convention, not an invariant the
trainer enforces. Two shipped adapters depart from it deliberately, each
documented at its own definition:
  - ClimODEFaithfulAdapter.forward returns a (mu, sigma) tuple of 5-D gridded
    tensors, consumed by its native_loss. Its predict() does return the
    standard 4-D tensor.
  - STGODEModel.forward returns (batch, H, N, 1) for any d, because upstream
    STGODE is a univariate forecaster; the trainer slices targets to match.

Train/eval mode ownership
-------------------------
The CALLER owns mode. The trainer sets `.train()` before the training loop and
`.eval()` before every evaluation pass, so an adapter may assume the mode is
already correct. Most adapters nevertheless re-assert it inside predict() (and
sometimes forward()); those calls are deliberate belt-and-braces, not a second
source of truth, and they are redundant under the trainer. STGODEAdapter sets
no mode at all, which is equally valid under this contract.

Grad context is a separate concern from mode: predict() implementations open
their own `torch.no_grad()` because the trainer's test loop calls
`.cpu().numpy()` on the returned tensor.
"""

import torch
import torch.nn as nn
from abc import ABC, abstractmethod
from typing import Dict, Any


class BaseAdapter(ABC):
    """
    Interface every model adapter implements so the shared trainer can drive it.

    A concrete adapter owns one vendored upstream model: it translates our
    config and (batch, T, N, d) tensors into whatever that repo expects, and
    translates the output back. It holds the instantiated module on
    `self.model`, which the trainer reaches for directly to move devices, set
    train/eval mode and checkpoint state.

    Subclasses must implement all four abstract methods below. The optional
    `uses_native_loss` / `native_loss` pair, the documented shape exceptions and
    the mode-ownership rule are described in the module docstring.
    """

    @abstractmethod
    def build_model(self, config: Dict[str, Any], graph: torch.Tensor) -> nn.Module:
        """
        Instantiate and return the model from the cloned repo.

        Args:
            config: merged experiment config dict.
            graph: adjacency matrix tensor of shape (N, N).

        Returns:
            The configured nn.Module.
        """
        raise NotImplementedError

    @abstractmethod
    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        """
        Forward pass during training. The caller has put the model in train
        mode and left gradients enabled.

        One exception: for an adapter that opts into `uses_native_loss`, the
        trainer also routes the validation pass through forward() (there is no
        predict() that yields the object native_loss consumes), so that adapter
        sees forward() called in eval mode inside no_grad as well.

        Args:
            x: input tensor of shape (batch, T, N, d).
            adj: adjacency matrix of shape (N, N).

        Returns:
            Predictions of shape (batch, H, N, d) for regression
            or (batch, H, N) for classification.
        """
        raise NotImplementedError

    @abstractmethod
    def predict(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        """
        Forward pass at evaluation time. The caller has already put the model
        in eval mode, but it does NOT open a grad-free context — the
        implementation is responsible for its own torch.no_grad().

        Separate from forward() because some models differ between training
        and inference — diffusion models run the full denoising chain at test
        time; ODE models may use tighter solver tolerances at evaluation.

        Args:
            x: input tensor of shape (batch, T, N, d).
            adj: adjacency matrix of shape (N, N).

        Returns:
            Predictions of shape (batch, H, N, d) for regression
            or (batch, H, N) for classification.
        """
        raise NotImplementedError

    @abstractmethod
    def get_param_count(self) -> int:
        """Return total trainable parameter count."""
        raise NotImplementedError
