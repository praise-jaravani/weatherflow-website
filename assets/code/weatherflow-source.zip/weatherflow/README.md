# WeatherFLOW

**UCT CSC4019Z Honours Project 2026**
Génevieve Chikwanha · Zoleka Fuyana · Praise Jaravani
Supervisor: Dr. Deshen Moodley

A benchmarking framework for spatio-temporal graph neural networks (STGNNs) on South African weather data.

---

## Table of contents

1. [What this is](#what-this-is)
2. [Quick start](#quick-start)
3. [Models](#models)
4. [Datasets and tasks](#datasets-and-tasks)
5. [Running experiments](#running-experiments)
6. [Running a campaign](#running-a-campaign-the-worker-system)
7. [Results and outputs](#results-and-outputs)
8. [Testing](#testing)
9. [HPC and containers](#hpc-and-containers)
10. [Project structure](#project-structure)
11. [Things worth knowing](#things-worth-knowing)

---

## What this is

WeatherFLOW compares four STGNN architectures on South African weather forecasting and extreme-event detection. The core idea, borrowed from [OpenSTL (NeurIPS 2023)](https://github.com/chengtan9907/OpenSTL), is strict layer separation: data and evaluation utilities at the bottom, vendored model implementations in the middle, a single CLI on top.

Every model shares the same preprocessed tensors, the same chronological split, the same loss function, the same evaluation suite, and the same seed protocol. The only thing that differs per model is a thin **adapter** file. That is what makes the numbers comparable.

Original model repositories are vendored under `models/<family>/<Name>/` and are **never edited**. Integration happens entirely through `*_adapter.py` and `*_model.py` wrappers, so we run exactly the code the original authors published.

---

## Quick start

### Prerequisites

- [Miniconda](https://docs.conda.io/en/latest/miniconda.html)
- Git
- Singularity/Apptainer — only if you are building the HPC container (Linux or WSL2)

### Set up

```bash
git clone --recurse-submodules <repo-url>
cd WeatherFLOW

conda env create -f environment.yml
conda activate weatherflow
```

`--recurse-submodules` pulls the vendored model repositories at their pinned commits.

### Confirm it works

```bash
make verify          # checks repos, configs, data dirs, container.def
make smoke           # 50-node, 1-seed, 2-epoch end-to-end run (~minutes)
```

A passing smoke test prints real (non-NaN) MAE and RMSE. If you see `nan`, something is wrong — see [Things worth knowing](#things-worth-knowing).

### Run something real

```bash
make run MODEL=clcrn DATASET=saws TASK=regression RUNS=1
```

---

## Models

Four models make up the production matrix. All are fully implemented and were run in the final campaign.

| Model | Family | Paper | Scheduler (paper-faithful) | Epochs |
|---|---|---|---|---|
| **AGCRN** | Baseline | Bai et al. 2020 | none — constant Adam | 100 |
| **CLCRN** | Baseline | Lin et al. 2022 | MultiStepLR `[10,20,30]`, γ=0.05 | 100 |
| **MTGODE** | Continuous-time | Jin et al. 2022 | MultiStepLR `[100]`, γ=0.1 | 200 |
| **STGODE** | Continuous-time | Fang et al. 2021 | none — constant Adam | 200 |

Each model's scheduler matches what its original paper specifies. Earlier versions of this harness applied `CosineAnnealingWarmRestarts` uniformly; that was replaced with per-paper schedules so results are faithful to the published methods.

Hyperparameters were set by Optuna TPE search on the N=32 SAWS network. Full provenance — which values came from papers, which from HPO, and why — is in [`specs/HYPERPARAMETERS.md`](specs/HYPERPARAMETERS.md).

**Also present but not in the production matrix:** `climode`, `climode_faithful`, `stlgru`, `litestgnn`. These have working adapters and configs but were mothballed during the project. Diffusion models (DiffSTG, USTD) live in Génevieve's separate fork.

All valid `--model` values:
`agcrn`, `clcrn`, `mtgode`, `stgode`, `climode`, `climode_faithful`, `stlgru`, `litestgnn`

---

## Datasets and tasks

### SAWS (primary)

South African Weather Service station observations. **32 stations**, 2016–2025, hourly, six variables: `t2m`, `tp`, `rh`, `wd`, `ws`, `sp`. Stations were selected by an audit requiring ≤10% overall missingness (Davidson 2022 criterion). This is the network all final results use.

Raw workbooks live in `data/saws/raw/`; station list at `data/saws/stations_32node.csv`.

A legacy 25-station network (2013–2020) is also parseable via `preprocessing/saws_parser_25node_lekuba.py`.

### ERA5 (secondary)

Hourly Copernicus reanalysis over a South Africa bounding box, 2000–2025 (317 monthly `.nc` files in `data/era5/raw/`). Eight variables including two derived (`ws10`, `rh`). Used for early development and cross-checks.

### Tasks

**Phase 1 — Regression.** Forecast future values for one target variable at a time (`t2m`, `sp`, `rh`, or `ws`), horizon H=48.
Metrics: MAE, RMSE, MSE, sMAPE, per-horizon MAE/RMSE/NRMSE curves, VPT (Valid Prediction Time), stratified MAE (extreme vs non-extreme), peak intensity error.

**Phase 2 — Classification.** Predict whether a future timestep exceeds an extreme threshold. One run predicts **all four label variables jointly** (`t2m`, `tp`, `rh`, `ws`), with metrics reported per variable.
Metrics per variable: precision, recall, F1, CSI, AUC-ROC, PR-AUC, confusion matrix, plus the validation-selected decision threshold τ.

> **Note on extremes.** Regression stratification uses a **static** per-station 95th-percentile threshold computed on the training split only. Phase-2 classification labels use the richer calendar-hour-relative (ETCCDI-style windowed percentile) scheme set by `data.threshold_scheme`.

---

## Running experiments

There are two ways in: the **Makefile** for everyday work, and **`cli.py`** directly when you need finer control.

### Makefile targets

```bash
# Environment
make verify                  # check setup is complete and wired up
make sync-env                # update conda env after requirements.txt changes
make activate-env            # print activation instructions

# Running
make run MODEL=clcrn DATASET=saws TASK=regression RUNS=1
make smoke MODEL=clcrn DATASET=saws TASK=regression
make preprocess DATASET=saws          # preprocessing only, no training
make baselines DATASET=saws TASK=regression   # AGCRN then CLCRN

# Results
make compare                 # cross-model table from outputs/
make ui                      # MLflow UI at http://localhost:5000

# Testing
make test                    # fast tests
make test-all                # everything, including slow ODE tests

# Housekeeping
make clean                   # remove __pycache__ (leaves vendored repos alone)
make help                    # list all targets
```

Variables you can override: `MODEL`, `DATASET`, `TASK`, `RUNS`, `MAX_NODES`, `PORT`, `HPC_USER`.

> The Makefile defaults to `DATASET=era5`. Production results use SAWS — pass `DATASET=saws` explicitly.

### Using `cli.py` directly

```bash
python cli.py --model <name> --dataset <saws|era5|both> --task <regression|classification> [options]
```

| Flag | Default | Meaning |
|---|---|---|
| `--model` | *required* | Any key from the model list above |
| `--dataset` | *required* | `saws`, `era5`, or `both` |
| `--task` | *required* | `regression` or `classification` |
| `--runs N` | `10` | Number of seeds to train |
| `--seed-start N` | `42` | First seed; runs `N` through `N+runs-1` |
| `--horizon H` | from config | Override forecast horizon |
| `--max-nodes N` | off | Subsample graph to first N nodes (smoke tests) |
| `--no-cache` | off | Force preprocessing rerun |
| `--mlflow-off` | off | Disable MLflow logging |

**Overriding any config value.** Any key in the model's YAML can be set inline with `--config.<dotted.path> <value>`. Types are coerced automatically.

```bash
# Forecast rainfall instead of temperature
python cli.py --model clcrn --dataset saws --task regression --runs 1 \
    --config.data.target_variable tp

# Short run with a different learning rate
python cli.py --model mtgode --dataset saws --task regression --runs 1 \
    --config.training.epochs 5 \
    --config.training.learning_rate 0.0005 \
    --config.training.batch_size 16
```

Config files live in `experiments/configs/<model>.yaml` — read one to see every available key.

---

## Running a campaign (the worker system)

A single `cli.py` invocation trains one model on one target. A **campaign** trains the whole matrix — every model × every target × every seed — unattended, in parallel, across multiple HPC jobs, surviving walltime limits.

This is what produced the final results. It has three pieces: a **manifest**, a **worker**, and a **Slurm chain**.

### 1. The manifest

A manifest is a flat JSON array of task IDs:

```json
["clcrn_t2m_s42", "clcrn_sp_s42", "mtgode_t2m_s42", ...]
```

| Task type | ID format | Example |
|---|---|---|
| Regression | `{model}_{target}_s{seed}` | `clcrn_t2m_s42` |
| Classification | `{model}_cls_s{seed}` | `clcrn_cls_s42` |

Classification has no target axis — one run covers all four label variables jointly.

Build one with:

```bash
python scripts/build_manifest.py \
    --task regression \
    --models clcrn mtgode stgode agcrn \
    --targets t2m sp rh ws \
    --seeds 42 43 44 \
    --out runs/manifest.json
```

Tasks are ordered **breadth-first by seed** (all model×target cells at seed 42, then all at seed 43…) with the slowest models first inside each round. This is deadline insurance: a partial campaign always gives you a complete matrix at some seed count rather than a few cells finished and the rest empty.

`--task` accepts `regression`, `classification`, or `both` — `both` interleaves Phase 1 and Phase 2 into a single chain. Defaults are sensible: omit `--models`, `--targets` and `--seeds` to get the standard matrix. Output defaults to `runs/manifest.json`, `runs/manifest_cls.json`, or `runs/manifest_all.json` respectively.

For a single ad-hoc run you can just write the file yourself:

```bash
echo '["clcrn_tp_s42"]' > runs/manifest.json
```

### 2. The worker

```bash
python scripts/run_worker.py --manifest runs/manifest.json
```

The worker loops: **claim a task → train it → write `summary.json` → repeat**, until the manifest is drained or it runs low on walltime.

Key behaviours:

- **Atomic claiming.** Claims are `os.mkdir(runs/claims/<task_id>/)` — atomic on Lustre/GPFS, so many workers can share one manifest with no coordination and no double-work.
- **Completion marker.** A task is done when `runs/<task_id>/summary.json` exists. Restarting a worker skips finished tasks automatically, so the campaign is fully resumable.
- **Stale-claim sweep.** On startup, claims belonging to jobs no longer in `squeue` are released. If `squeue` is unreachable the sweep does nothing rather than guessing, so live work is never stolen.
- **Walltime awareness.** The worker tracks an exponential moving average of per-model runtime and refuses to start a task it cannot finish before the job expires.
- **Graceful stop.** Slurm sends `SIGUSR1` 20 minutes before walltime. The worker finishes the current epoch, checkpoints to `state.pt`, keeps its claim, and exits cleanly. The next job in the chain resumes from that checkpoint.

Useful flags: `--manifest`, `--runs-dir`, `--claims-dir`, `--epochs` (override for smoke tests), `--wallclock-margin`.

### 3. The Slurm chain (multithreaded)

```bash
sbatch slurm/worker.sh
```

One `sbatch` submission is enough. `slurm/worker.sh` does three things:

1. **Submits its own successor** with `--dependency=afterany`, so when it hits the 24h walltime cap the next job starts automatically. The chain continues until the manifest is drained or `MAX_LINKS` is reached.
2. **Launches K parallel training processes** on the single GPU (default `K_PROCS=3`), staggered by 20s so they do not collide during cache load and CUDA init. Each writes to its own log: `logs/wf_worker-<jobid>-p<N>.out`.
3. **Forwards `SIGUSR1`** to every Python child. This is done explicitly via `pgrep` because the Apptainer starter process does not forward signals into the container.

The three processes claim independently from the shared manifest, so you get 3× throughput with no scheduling logic.

**Environment overrides:**

| Variable | Default | Meaning |
|---|---|---|
| `MANIFEST` | `runs/manifest.json` | Which manifest to drain |
| `K_PROCS` | `3` | Concurrent trainings per GPU |
| `PROC_STAGGER` | `20` | Seconds between process launches |
| `MAX_LINKS` | `10` | Cap on chain length (runaway guard) |
| `WALLCLOCK_MARGIN` | `1500` | Seconds reserved before walltime |
| `REPO` | *(scratch path)* | Repo root on the cluster |
| `CONTAINER` | *(scratch path)* | Path to `container.sif` |

```bash
# Phase 2 campaign with 2 processes instead of 3
sbatch --export=ALL,MANIFEST=runs/manifest_cls.json,K_PROCS=2 slurm/worker.sh
```

Successors inherit these via `--export=ALL`.

### Monitoring a campaign

```bash
squeue -u $USER                                              # jobs
find runs -maxdepth 2 -name summary.json | wc -l             # tasks complete
tail -f logs/wf_worker-<jobid>-p1.out                        # live progress
```

Other worker scripts in `slurm/`: `hpo_worker.sh`, `hpo_agcrn_worker.sh`, `hpo_optuna_worker.sh` (hyperparameter search) and `case_study_extract.sbatch`.

Deeper detail lives in [`specs/HPC_Parallel_Worker_System.md`](specs/HPC_Parallel_Worker_System.md) and [`specs/WeatherFLOW_HPC_Runbook.md`](specs/WeatherFLOW_HPC_Runbook.md).

---

## Results and outputs

Two different layouts depending on how you ran things.

**`cli.py` / Makefile runs** land in `outputs/<timestamp>/`, one subfolder per seed plus an aggregated `summary.json`.

**Campaign runs** land in `runs/<task_id>/`:

| File | Contents |
|---|---|
| `summary.json` | Everything — config, per-epoch losses, all test metrics, timing. Also the completion marker. |
| `test_metrics.json` | Test metrics alone |
| `per_station.npz` | Per-station `(N, d)` MAE / RMSE / extreme metrics |
| `train.log` | Per-epoch training log |
| `state.pt` | Resume checkpoint (mid-run) |
| `checkpoint.pt` | Best-epoch model weights |

Raw prediction tensors are **not** saved — metrics are computed and the tensors discarded. To recover predictions, reload `checkpoint.pt` and re-run inference on the test set.

Comparison helpers:

```bash
make compare                                 # table across outputs/
python scripts/compare_results.py runs/ --format csv --wilcoxon
```

MLflow logs every `cli.py` run to `tracking/mlflow.db` (gitignored). `make ui` to browse.

---

## Testing

**334 tests** across 19 files, covering preprocessing, evaluation, orchestration, adapters, and integration.

```bash
make test        # fast subset — skips slow ODE forward passes
make test-all    # everything

# or directly
pytest tests/ -v -m "not slow"
pytest tests/test_orchestration.py -v
```

---

## HPC and containers

Production runs happen on UCT HPC inside a Singularity container. HPC clusters do not support Docker (it needs root); Singularity is the standard alternative.

`container.def` is the source of truth. Its base image is an NVIDIA NGC PyTorch container validated for the GPU's CUDA architecture — generic PyTorch images often omit the right compute capability and fail at runtime.

```bash
make build-container                          # Linux/WSL2 only, ~11 GB output
make upload-container HPC_USER=<uct-username>
make sync-hpc HPC_USER=<uct-username>         # both at once
```

Verify on the cluster:

```bash
singularity exec --nv container.sif python -c "import torch; print(torch.cuda.is_available())"
```

Then submit as described in [Running a campaign](#running-a-campaign-the-worker-system).

> **GPU access.** UCT HPC accounts do not have GPU partition access by default — request it from `eresearch@uct.ac.za` with your supervisor CC'd.

---

## Project structure

```
WeatherFLOW/
├── cli.py                    ← single entry point for experiments
├── Makefile                  ← everyday commands
├── container.def             ← Singularity definition (HPC environment)
├── environment.yml           ← conda environment
│
├── experiments/configs/      ← one YAML per model
├── preprocessing/            ← parse → derive → impute → split → label → normalise → graph
├── models/
│   ├── base_adapter.py       ← the interface every adapter implements
│   ├── baselines/            ← AGCRN, CLCRN
│   ├── continuous_time/      ← MTGODE, STGODE, ClimODE
│   ├── lightweight/          ← STLGRU, Lite-STGNN
│   └── shared_modules/
├── training/                 ← trainer, losses, schedulers, seeding
├── evaluation/               ← regression, classification, computational, stats
├── orchestration/            ← manifest + atomic claim system
│
├── scripts/                  ← build_manifest, run_worker, compare_results, download_era5, …
├── slurm/                    ← worker.sh and HPO variants
├── tests/                    ← 334 tests
├── specs/                    ← design documents and audit trail
│
├── data/                     ← saws/ and era5/ raw inputs
├── runs/                     ← campaign outputs (one dir per task)
├── outputs/                  ← cli.py run outputs
└── results/                  ← aggregated analysis artefacts
```

`ARCHITECTURE.md` has the full design rationale. `specs/` holds the methodological audit trail — scheduler decisions, adjacency audits, hyperparameter provenance, horizon extension, VPT definition.

---

## Things worth knowing

**The adapter contract.** Every model implements four methods from `models/base_adapter.py`: `build_model()`, `forward()`, `predict()`, `get_param_count()`. The trainer calls `forward()` during training and `predict()` at validation/test — they can legitimately differ (a diffusion model might shorten its denoising chain during training).

**Never edit the vendored repos.** Patch upstream bugs in the `*_model.py` wrapper instead. AGCRN and CLCRN both needed fixes and were handled this way, which keeps the vendored code byte-identical to what the authors published.

**The preprocessing cache.** Keyed on a SHA-256 of the set of monthly data files plus the preprocessing config — *not* file mtimes. Re-downloading a month without changing the file set does **not** invalidate the cache. Adding or removing a month, or changing a preprocessing config key, does. Use `--no-cache` to force a rebuild. Cache lives in `preprocessing/cache/` (gitignored).

**Leakage safety.** The split always precedes labelling and normalisation. Percentile thresholds and z-score statistics are computed on the training split only, never on the full series.

**NaN losses.** Two usual causes. First, precipitation is extremely right-skewed — z-scores reach 57σ. The pipeline clips normalised features to ±10σ at DataLoader build time. Second, uninitialised weights: `torch.FloatTensor(shape)` allocates raw memory and can produce NaN on the very first forward pass. Use `torch.zeros()`, `torch.randn()`, or `nn.init.*`.

**Loss function.** Training uses **MAE (L1)** for regression, uniformly across all models — this matches what AGCRN, CLCRN and MTGODE all do in their own repositories. Classification uses weighted BCE with per-variable `pos_weight` derived from training-split positive rates. MSE is reported as a metric but never optimised.

**Seeds.** Seeds start at 42 by convention. `seed_everything()` sets Python, NumPy, PyTorch CPU and PyTorch CUDA together. Same seed + same config + same data should reproduce exactly.

**CLCRN and small graphs.** CLCRN's `k_neighbors` default is 25, which requires at least 26 nodes. Smoke-testing with `--max-nodes 8` will crash in the kernel generator — pass `--config.model.k_neighbors 4` alongside it.
