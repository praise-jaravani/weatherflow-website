# WeatherFLOW — source archive

Honours project, Department of Computer Science, University of Cape Town, 2026.
Génevieve Chikwanha · Zoleka Fuyana · Praise Jaravani
Supervisor: A/Prof Deshendran Moodley

This archive accompanies the project website and contains the **source code
only**. The following are deliberately excluded:

- `data/` — South African Weather Service station observations. Supplied for
  research use under the SAWS data policy and not ours to redistribute.
  Available on request from SAWS; the station list with coordinates and
  elevations is in the appendices of the final papers.
- trained checkpoints, raw run outputs, logs and the Singularity container
  image — together over 19 GB and reproducible from the code.

## Layout

    preprocessing/   parsing, imputation, chronological splitting, normalisation
    models/          adapters wrapping each upstream architecture
      baselines/       AGCRN, CLCRN
      continuous_time/ MTGODE, STGODE
      lightweight/     STLGRU, LiteSTGNN
    genevieve/       diffusion workstream — DiffSTG, USTD
    training/        shared training harness
    evaluation/      metrics, baselines, statistical comparison
    experiments/     experiment configuration
    orchestration/   campaign management and run manifests
    scripts/         analysis and figure generation
    slurm/           HPC job scripts
    tests/           test suite
    docs/, specs/    design notes and runbooks

Upstream model repositories are vendored at pinned commits and are not modified;
each integration is an adapter behind a common interface, so experiments run the
code the original authors released.

See `README.md` and `ARCHITECTURE.md` for the full description.
